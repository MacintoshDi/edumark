<?php

namespace App\Filament\Resources\PricingCategoryResource\Pages;

use App\Filament\Resources\PricingCategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePricingCategory extends CreateRecord
{
    protected static string $resource = PricingCategoryResource::class;
}
