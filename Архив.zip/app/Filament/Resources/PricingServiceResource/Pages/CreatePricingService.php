<?php

namespace App\Filament\Resources\PricingServiceResource\Pages;

use App\Filament\Resources\PricingServiceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePricingService extends CreateRecord
{
    protected static string $resource = PricingServiceResource::class;
}
