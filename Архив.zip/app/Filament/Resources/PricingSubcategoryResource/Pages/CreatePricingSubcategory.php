<?php

namespace App\Filament\Resources\PricingSubcategoryResource\Pages;

use App\Filament\Resources\PricingSubcategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePricingSubcategory extends CreateRecord
{
    protected static string $resource = PricingSubcategoryResource::class;
}
