# Edumark E-Learning Community Platform

A complete Laravel 11 e-learning community platform with cohorts, discussions, events, job board, gamification, and mentorship features.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Laravel](https://img.shields.io/badge/Laravel-11.x-red.svg)
![PHP](https://img.shields.io/badge/PHP-8.2+-purple.svg)

## 📋 Table of Contents

- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage](#usage)
- [Admin Panel](#admin-panel)
- [File Structure](#file-structure)
- [Troubleshooting](#troubleshooting)
- [License](#license)

## ✨ Features

### Core Features
- **Cohort Management**: Group-based learning with enrollment, resources, and assignments
- **Discussion Forums**: Threaded discussions with likes, solutions, and Q&A
- **Student Directory**: Searchable directory with profiles, follows, and networking
- **Events Management**: Virtual/in-person events with registration and calendars
- **Job Board**: Post and apply for jobs with filters and applications tracking
- **Mentorship System**: Match mentors and mentees based on interests and goals
- **Resource Library**: Upload and share files, links, and videos
- **Assignment System**: Create assignments, submit work, and grade submissions
- **Gamification**: Badges, points, and leaderboards for engagement
- **Private Messaging**: Direct communication between users
- **Activity Feed**: Track user activities and contributions
- **Spotlight & Showcase**: Feature success stories and student projects

### Technical Features
- Laravel 11 framework
- Filament 3.x admin panel
- Livewire for dynamic components
- Tailwind CSS for styling
- Laravel Breeze for authentication
- MySQL database
- Role-based access control (Student, Teacher, Alumni, Admin)
- Responsive design
- RESTful API structure
- Image uploads and file management
- Search functionality
- Email notifications

## 📦 Requirements

- PHP >= 8.2
- Composer
- Node.js >= 18.x & NPM
- MySQL >= 8.0 or MariaDB >= 10.3
- Git

## 🚀 Installation

### Step 1: Clone or Create Project

#### Option A: Start Fresh
```bash
composer create-project laravel/laravel edumark
cd edumark
```

#### Option B: Clone Repository (if you have it in Git)
```bash
git clone https://github.com/yourusername/edumark.git
cd edumark
composer install
```

### Step 2: Install Dependencies

```bash
# Install PHP dependencies
composer require laravel/breeze --dev
composer require filament/filament:"^3.0"
composer require livewire/livewire
composer require spatie/laravel-permission
composer require intervention/image

# Install Laravel Breeze
php artisan breeze:install blade
```

### Step 3: Install Node Dependencies

```bash
npm install
npm install -D @tailwindcss/forms @tailwindcss/typography @tailwindcss/line-clamp
```

### Step 4: Environment Configuration

```bash
cp .env.example .env
php artisan key:generate
```

Edit `.env` file with your configuration:

```env
APP_NAME="Edumark"
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=edumark
DB_USERNAME=root
DB_PASSWORD=your_password

FILESYSTEM_DISK=public

MAIL_MAILER=log
MAIL_FROM_ADDRESS="noreply@edumark.com"
MAIL_FROM_NAME="${APP_NAME}"
```

### Step 5: Database Setup

```bash
# Create database
mysql -u root -p
CREATE DATABASE edumark CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;

# Create storage link
php artisan storage:link

# Run migrations
php artisan migrate

# Seed database with demo data
php artisan db:seed
```

### Step 6: Install Filament Admin Panel

```bash
php artisan filament:install --panels

# Create admin user
php artisan make:filament-user
```

Follow the prompts to create your admin account.

### Step 7: Build Assets

```bash
npm run build
# or for development with hot reload
npm run dev
```

### Step 8: Start Development Server

```bash
php artisan serve
```

Visit:
- **Frontend**: http://localhost:8000
- **Admin Panel**: http://localhost:8000/admin

## ⚙️ Configuration

### File Storage

By default, files are stored locally in `storage/app/public`. To use S3 or other services, update `.env`:

```env
FILESYSTEM_DISK=s3
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
AWS_DEFAULT_REGION=us-east-1
AWS_BUCKET=your-bucket
```

### Email Configuration

For production, configure email:

```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=your-username
MAIL_PASSWORD=your-password
MAIL_ENCRYPTION=tls
```

### Queue Configuration

For better performance, use queues:

```env
QUEUE_CONNECTION=database
```

Then run:
```bash
php artisan queue:table
php artisan migrate
php artisan queue:work
```

## 📚 Usage

### Default Credentials

After seeding, use these credentials:

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@edumark.com | password |
| Teacher | teacher@edumark.com | password |
| Student | sarah-johnson@student.com | password |

### User Roles

1. **Admin**
   - Full access to admin panel
   - Manage all users, cohorts, content
   - View analytics and reports

2. **Teacher**
   - Create and manage cohorts
   - Create assignments and grade submissions
   - Moderate discussions
   - Manage resources

3. **Student**
   - Enroll in cohorts
   - Participate in discussions
   - Submit assignments
   - Register for events
   - Apply for jobs

4. **Alumni**
   - Similar to students
   - Can be mentors
   - Access to alumni-specific features

### Creating a Cohort

1. Log in to admin panel (/admin)
2. Navigate to "Cohorts" → "Create"
3. Fill in cohort details:
   - Name, description, category
   - Start/end dates
   - Maximum students
   - Price (if applicable)
4. Set status to "Published" to make it visible
5. Save the cohort

### Managing Content

#### Resources
- Upload files (PDF, DOC, PPT, etc.)
- Add external links
- Organize by order

#### Assignments
- Set title, description, instructions
- Configure max points and due date
- Allow/disallow late submissions

#### Events
- Create virtual or in-person events
- Set date, time, and capacity
- Add meeting URL for virtual events

## 🎨 Customization

### Changing Theme Colors

Edit `tailwind.config.js`:

```javascript
theme: {
    extend: {
        colors: {
            'primary': {
                // Your custom colors
            },
        },
    },
},
```

### Adding Custom Pages

1. Create route in `routes/web.php`
2. Create controller: `php artisan make:controller YourController`
3. Create view in `resources/views/`
4. Add navigation link in `resources/views/layouts/app.blade.php`

### Modifying Admin Panel

Filament resources are in `app/Filament/Resources/`. Customize:
- Form fields
- Table columns
- Filters and actions
- Permissions

## 🔧 Admin Panel

Access: http://localhost:8000/admin

### Features

- **Dashboard**: Overview of platform statistics
- **User Management**: CRUD operations for all users
- **Cohort Management**: Create and manage learning cohorts
- **Content Management**: Discussions, events, jobs, resources
- **Gamification**: Manage badges and points
- **Settings**: Categories, site configuration
- **Reports**: Analytics and user behavior insights

### Creating Admin Users

```bash
php artisan make:filament-user
```

Or via tinker:
```bash
php artisan tinker
>>> $user = User::create(['name' => 'Admin', 'email' => 'admin@example.com', 'password' => bcrypt('password'), 'role' => 'admin']);
```

## 📁 File Structure

```
edumark/
├── app/
│   ├── Filament/
│   │   └── Resources/         # Admin panel resources
│   ├── Http/
│   │   ├── Controllers/       # Application controllers
│   │   └── Middleware/        # Custom middleware
│   ├── Models/                # Eloquent models
│   └── Policies/              # Authorization policies
├── database/
│   ├── migrations/            # Database migrations
│   ├── seeders/               # Database seeders
│   └── factories/             # Model factories
├── public/
│   └── storage/               # Public storage (symlink)
├── resources/
│   ├── css/
│   │   └── app.css           # Tailwind CSS
│   ├── js/
│   │   └── app.js            # JavaScript
│   └── views/
│       ├── layouts/          # Blade layouts
│       ├── components/       # Reusable components
│       ├── cohorts/          # Cohort views
│       ├── discussions/      # Discussion views
│       ├── events/           # Event views
│       └── ...               # Other views
├── routes/
│   ├── web.php               # Web routes
│   └── api.php               # API routes
├── storage/
│   ├── app/
│   │   ├── public/           # User uploads
│   │   └── private/          # Private files
│   └── logs/                 # Application logs
├── .env                      # Environment configuration
├── composer.json             # PHP dependencies
├── package.json              # Node dependencies
├── tailwind.config.js        # Tailwind configuration
└── README.md                 # This file
```

## 🎯 Key Routes

### Public Routes
- `/` - Homepage (Welcome page)
- `/login` - User login
- `/register` - User registration

### Authenticated Routes
- `/dashboard` - User dashboard
- `/cohorts` - Browse cohorts
- `/cohorts/{slug}` - Cohort details
- `/discussions` - Discussion forum
- `/ask-your-teacher` - Q&A section
- `/student-directory` - User directory
- `/events` - Events calendar
- `/jobs` - Job board
- `/connect` - Messaging
- `/spotlight` - Featured content
- `/showcase` - User portfolios

### Admin Routes
- `/admin` - Admin dashboard
- `/admin/users` - User management
- `/admin/cohorts` - Cohort management
- `/admin/discussions` - Discussion moderation
- `/admin/events` - Event management
- `/admin/jobs` - Job postings
- `/admin/badges` - Badge management

## 🔐 Security

### Best Practices

1. **Change Default Passwords**: Always change default passwords in production
2. **Enable HTTPS**: Use SSL certificates for production
3. **Set APP_DEBUG=false**: In production environment
4. **Secure .env**: Never commit `.env` to version control
5. **Regular Updates**: Keep Laravel and dependencies updated

### Rate Limiting

API routes are rate-limited. Adjust in `app/Providers/RouteServiceProvider.php`:

```php
RateLimiter::for('api', function (Request $request) {
    return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
});
```

## 🐛 Troubleshooting

### Common Issues

#### 1. Storage Permission Errors
```bash
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

#### 2. Symlink Issues
```bash
php artisan storage:link
```

#### 3. Asset Build Errors
```bash
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
npm run build
```

#### 4. Database Connection Errors
- Verify database credentials in `.env`
- Ensure MySQL is running
- Check database exists: `SHOW DATABASES;`

#### 5. Class Not Found Errors
```bash
composer dump-autoload
php artisan cache:clear
php artisan config:clear
php artisan view:clear
```

#### 6. Filament Panel Not Loading
```bash
php artisan filament:upgrade
php artisan optimize:clear
```

### Debug Mode

Enable detailed error messages:
```env
APP_DEBUG=true
APP_ENV=local
```

Check logs:
```bash
tail -f storage/logs/laravel.log
```

## 📊 Database Schema

### Core Tables

- **users** - User accounts and profiles
- **cohorts** - Learning cohorts
- **cohort_user** - Enrollment pivot table
- **categories** - Hierarchical categories
- **discussions** - Forum discussions
- **replies** - Discussion replies
- **resources** - Learning resources
- **assignments** - Course assignments
- **submissions** - Assignment submissions
- **events** - Calendar events
- **event_user** - Event registrations
- **jobs_board** - Job postings
- **job_applications** - Job applications
- **badges** - Achievement badges
- **badge_user** - User badges
- **messages** - Private messages
- **mentorships** - Mentor-mentee relationships
- **spotlights** - Featured content
- **showcases** - User portfolios
- **likes** - Polymorphic likes
- **follows** - User follows
- **activity_log** - User activity tracking
- **notifications** - User notifications

## 🚀 Deployment

### Production Optimization

```bash
# Optimize configuration
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Install production dependencies
composer install --optimize-autoloader --no-dev

# Build assets
npm run build

# Set permissions
chmod -R 755 /path/to/edumark
chmod -R 775 storage bootstrap/cache
```

### Environment Variables for Production

```env
APP_ENV=production
APP_DEBUG=false
APP_URL=https://yourdomain.com

# Use queue for better performance
QUEUE_CONNECTION=redis

# Use Redis for caching
CACHE_DRIVER=redis
SESSION_DRIVER=redis

# Configure email
MAIL_MAILER=smtp
# ... your SMTP settings
```

### Web Server Configuration

#### Nginx Example

```nginx
server {
    listen 80;
    server_name edumark.yourdomain.com;
    root /var/www/edumark/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

#### Apache Example

```apache
<VirtualHost *:80>
    ServerName edumark.yourdomain.com
    DocumentRoot /var/www/edumark/public

    <Directory /var/www/edumark/public>
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/edumark_error.log
    CustomLog ${APACHE_LOG_DIR}/edumark_access.log combined
</VirtualHost>
```

### Process Manager (Supervisor)

For queue workers:

```ini
[program:edumark-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/edumark/artisan queue:work --sleep=3 --tries=3
autostart=true
autorestart=true
user=www-data
numprocs=2
redirect_stderr=true
stdout_logfile=/var/www/edumark/storage/logs/worker.log
```

## 🧪 Testing

### Run Tests

```bash
php artisan test
```

### Create Tests

```bash
php artisan make:test CohortTest
```

## 📈 Performance Optimization

### Enable Caching

```bash
# Cache configuration
php artisan config:cache

# Cache routes
php artisan route:cache

# Cache views
php artisan view:cache
```

### Use Queue for Long Tasks

```bash
# Run queue worker
php artisan queue:work

# Or use supervisor for production
```

### Database Optimization

```bash
# Index important columns
# Add to migrations:
$table->index('email');
$table->index(['user_id', 'cohort_id']);

# Use eager loading to prevent N+1 queries
Cohort::with(['category', 'students'])->get();
```

## 📝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For issues and questions:

- **Documentation**: Check Laravel docs at https://laravel.com/docs
- **Filament Docs**: https://filamentphp.com/docs
- **GitHub Issues**: Create an issue in the repository
- **Email**: support@edumark.com

## 🎉 Acknowledgments

- Laravel Framework - https://laravel.com
- Filament Admin Panel - https://filamentphp.com
- Tailwind CSS - https://tailwindcss.com
- Livewire - https://laravel-livewire.com
- Original Edumark Template by Bettermode

## 🔄 Updates & Maintenance

### Check for Updates

```bash
composer update
npm update
```

### Clear All Caches

```bash
php artisan optimize:clear
```

### Backup Database

```bash
mysqldump -u username -p edumark > backup_$(date +%Y%m%d).sql
```

## 📞 Quick Commands Reference

```bash
# Development
php artisan serve                    # Start dev server
npm run dev                          # Watch assets
php artisan tinker                   # REPL console

# Database
php artisan migrate                  # Run migrations
php artisan migrate:fresh --seed    # Fresh database with seeds
php artisan db:seed                  # Seed database

# Cache
php artisan cache:clear              # Clear cache
php artisan config:clear             # Clear config
php artisan route:clear              # Clear routes
php artisan view:clear               # Clear views
php artisan optimize:clear           # Clear all

# Filament
php artisan make:filament-resource   # Create resource
php artisan filament:upgrade         # Upgrade Filament

# Queue
php artisan queue:work               # Process queue
php artisan queue:failed             # List failed jobs
php artisan queue:retry all          # Retry failed jobs

# Maintenance
php artisan down                     # Enable maintenance mode
php artisan up                       # Disable maintenance mode
```

---

**Built with ❤️ for the education community**