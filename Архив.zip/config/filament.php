<?php

return [
    'panels' => [
    App\Providers\Filament\AdminPanelProvider::class,
],

];